
https://medium.com/@awangenh/mapping-weeds-and-crops-in-precision-agriculture-with-convolutional-neural-networks-138dab87ba00

https://lapix.ufsc.br/crop-rows-sugar-cane/

https://lapix.ufsc.br/weed-mapping-sugar-cane/
https://github.com/awangenh/Weed-Mapping
